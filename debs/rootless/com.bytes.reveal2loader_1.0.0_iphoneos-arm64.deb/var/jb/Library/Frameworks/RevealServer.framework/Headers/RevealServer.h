//
//  Copyright © 2015 Itty Bitty Apps, Pty Ltd. All rights reserved.

#import <UIKit/UIKit.h>

//! Project version number for RevealServer.
FOUNDATION_EXPORT double RevealServerVersionNumber;

//! Project version string for RevealServer.
FOUNDATION_EXPORT const unsigned char RevealServerVersionString[];

